var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","6066a515-8626-40b6-aedd-f360d82a5758","54e65268-15e7-4a7a-8f7f-781ded54489f","083b9ac3-7a9f-427d-b6db-c4d6b9c3b650","69dc158e-b498-4a9f-a7f7-de46675f8e4d","0cde1048-05ee-4d43-83c5-78659d6cc794"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":9,"looping":true,"frameDelay":5,"version":"bzCAhKNybR_9G_WodF.mSxTwdI6F47SM","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":"rw5brtcgFtIEzhnKMqb_1v5hvWflVzyR","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone1","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bGtAEXMo5DERBNaArgHgod3yof6FSSFC","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"6066a515-8626-40b6-aedd-f360d82a5758":{"name":"Stone2","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bGtAEXMo5DERBNaArgHgod3yof6FSSFC","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"54e65268-15e7-4a7a-8f7f-781ded54489f":{"name":"Stone3","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bGtAEXMo5DERBNaArgHgod3yof6FSSFC","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"083b9ac3-7a9f-427d-b6db-c4d6b9c3b650":{"name":"Stone4","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bGtAEXMo5DERBNaArgHgod3yof6FSSFC","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"69dc158e-b498-4a9f-a7f7-de46675f8e4d":{"name":"Stone5","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bGtAEXMo5DERBNaArgHgod3yof6FSSFC","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"0cde1048-05ee-4d43-83c5-78659d6cc794":{"name":"Stone6","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"bGtAEXMo5DERBNaArgHgod3yof6FSSFC","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


//create a trex sprite
var trex = createSprite(220,360,20,50);
trex.setAnimation("monkey");
var obstacleGroup=createGroup();
var fruitgroup=createGroup();


var invisibleSprite= createSprite(200,385,400,5);
invisibleSprite.visible= false;


//scale and position the trex
trex.scale = 0.15;
trex.x = 50;

//create a ground sprite
var ground = createSprite(200,380,400,20);
ground.x = ground.width /2;
ground.visible=false;
function draw() {
  //set background to white
background("white");
  
  ground.velocityX = -2;
  //console.log(trex.y);
  
    if (ground.x < 0){
    ground.x = ground.width/2;
    }
  
  //jump when the space key is pressed
    if(keyDown("space")&&trex.y>=336.25){
    trex.velocityY = -10 ;
    }
  
  //add gravity
  trex.velocityY = trex.velocityY + 0.8;
  
  //stop trex from falling down
  trex.collide(invisibleSprite);
  drawSprites();
  Bananas();
  stone();
  if(obstacleGroup.isTouching(trex)){
    obstacleGroup.destroyEach();
    trex.destroy();
    fruitgroup.destroyEach();
  }
var time=0;
time=Math.ceil(frameCount/frameRate());
text("Survival Time:"+time,100,50);
stroke("black");
fill("black");
textSize("20");
  
}




 function Bananas(){
   if(World.frameCount%80===0){
   var Banana=createSprite(400,randomNumber(200,250),10,10);
   Banana.velocityX=-3;
   Banana.setAnimation("Banana");
   Banana.scale=0.05;
  Banana.depth=trex.depth;
  trex.depth=trex.depth+1;
  fruitgroup.add(Banana);
  Banana.lifetime=-1;
   }
 }
 
 function stone(){
   if(World.frameCount%300===0){
     var Stone=createSprite(400,350,10,10);
     Stone.velocityX=-3;
     Stone.setAnimation("Stone1");
     Stone.scale=0.15;
     trex.depth=Stone.depth;
     obstacleGroup.add(Stone);
     Stone.lifetime=-1;
   }
 }
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
